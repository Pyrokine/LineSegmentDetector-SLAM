#include <myFA.h>

using namespace cv;
using namespace std;

namespace myfa {
	//���̵߳������������������
	int num_tasks = 0;
	int num_done = 0;
	//pthread�Ļ�����
	pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

	structFAOutput FeatureAssociation(structFAInput *FAInput) {
		//���룺LSD��RDP�㷨�õ����߶������Լ������ͼ
		//�������λ���
		int sizeScanLine = (int)FAInput->scanLinesInfo.size();
		int sizeMapLine = (int)FAInput->mapLinesInfo.size();
		//��ʼ����������
		num_tasks = 0;
		num_done = 0;
		//��ʼ���̳߳�
		threadpool_t *pool = threadpool_create(numTHREAD, lenQUEUE, 0);
		//��ʼ��Score
		vector<structScore> Score;
		structFAOutput FAOutput;

		int cntScanLine = 0;
		//��RDP�߶���Ϊ��׼����ƥ��
		for (cntScanLine = 0; cntScanLine < sizeScanLine; cntScanLine++) {
			double lenScanLine = FAInput->scanLinesInfo[cntScanLine].len;
			//���Թ��̵��߶�
			if (lenScanLine < ignoreScanLength)
				continue;

			double lenDiff = FAInput->scanLinesInfo[cntScanLine].len * scanToMapDiff;
			int cntMapLine = 0;
			for (cntMapLine = 0; cntMapLine < sizeMapLine; cntMapLine++) {
				double lenMapLine = FAInput->mapLinesInfo[cntMapLine].len;
				//�Գ��Ȳ���һ����Χ�ڵ��߶ν���ƥ��
				if (lenMapLine < lenScanLine - lenDiff || lenMapLine > lenScanLine + lenDiff)
					continue;

				//���߳�����
				//ScanToMapMatch(FAInput, cntMapLine, cntScanLine, &Score);

				//���̲߳�������
				//�ȴ�����ճ�
				while (num_tasks - num_done > lenQUEUE);
				//����
				structThreadSTMM *argSTMM = (structThreadSTMM*)malloc(sizeof(structThreadSTMM));
				argSTMM->cntMapLine = cntMapLine;
				argSTMM->cntScanLine = cntScanLine;
				argSTMM->FAInput = FAInput;
				argSTMM->Score = &Score;
				//��������
				threadpool_add(pool, &thread_ScanToMapMatch, argSTMM, 0);
				pthread_mutex_lock(&mutex);
				num_tasks++;
				pthread_mutex_unlock(&mutex);
			}
		}
		//�ȴ�������������������̣߳���֪BUG��������һ����������������
		//�������ӵȴ�ʱ���Խ����ȴ�
		while (num_tasks - num_done > 1);
		threadpool_destroy(pool, 0);

		int lenScore = 0;
		structScore *poseAll;
		structScore poseEstimate;
		//�ж��Ƿ���ƥ�������������򴴽��µ��������Ʒ���
		if (Score.empty()) {
			poseEstimate.pos.x = -1;
			poseEstimate.pos.y = -1;
			poseEstimate.pos.ang = 0;
			poseEstimate.score = INFINITY;
			Eigen::Matrix<double, 9, 1> kalman_x;
			Eigen::Matrix<double, 9, 9> kalman_P;
			kalman_x << -1, -1, 0, 0, 0, 0, 0, 0, 0;
			kalman_P << 100, 0, 0, 0, 0, 0, 0, 0, 0,
						0, 100, 0, 0, 0, 0, 0, 0, 0,
						0, 0, 100, 0, 0, 0, 0, 0, 0,
						0, 0, 0, 1, 0, 0, 0, 0, 0,
						0, 0, 0, 0, 1, 0, 0, 0, 0,
						0, 0, 0, 0, 0, 1, 0, 0, 0,
						0, 0, 0, 0, 0, 0, 0.1, 0, 0,
						0, 0, 0, 0, 0, 0, 0, 0.1, 0,
						0, 0, 0, 0, 0, 0, 0, 0, 0.1;
			FAOutput.kalman_x = kalman_x;
			FAOutput.kalman_P = kalman_P;
			return FAOutput;
		}
		else {
			lenScore = (int)Score.size();
			poseAll = new structScore[lenScore * sizeof(structScore)];
			memcpy(poseAll, &Score[0], lenScore * sizeof(structScore));
		}
		//ȷ��Scorre��͵Ľ��Ϊ��һ��ƥ��Ļ�׼��
		qsort(poseAll, lenScore, sizeof(structScore), CompScore);

		//�����������Ʒ�����һ֡
		if (abs(FAInput->lastPose.x + 1) < 0.0001) {
			poseEstimate = poseAll[0];
			FAOutput.kalman_x(0) = poseEstimate.pos.x;
			FAOutput.kalman_x(1) = poseEstimate.pos.y;
			FAOutput.kalman_x(2) = poseEstimate.pos.ang;
			FAOutput.kalman_P = FAInput->kalman_P;
			return FAOutput;
		}

		//�������Ʒ����м�֡
		double scaThre = 0;
		int cntPoseAll = 0, lenPoseSimilar = 0;
		vector<structScore> poseSimilar;
		//��10%�Ĳ�����С����ɸѡScore
		for (scaThre = 0; scaThre <= 0.8; scaThre += 0.1) {
			for (cntPoseAll = (int)(scaThre * lenScore); cntPoseAll < (int)((scaThre + 0.1) * lenScore); cntPoseAll++) {
				//�ų���INF��socre
				if (poseAll[cntPoseAll].score < INFINITY) {
					//����ȡ����maxEstiDist�������ڵĺ�ѡ��
					if (sqrt(pow(poseAll[cntPoseAll].pos.x - FAInput->lastPose.x, 2) + pow(poseAll[cntPoseAll].pos.y - FAInput->lastPose.y, 2)) < maxEstiDist) {
						poseSimilar.push_back(poseAll[cntPoseAll]);
					}
				}
			}
			if (poseSimilar.size() > lenCandidate)
				break;
		}

		lenPoseSimilar = poseSimilar.size();
		//��ƥ�����������µ��������Ʒ���
		if (lenPoseSimilar == 0) {
			poseEstimate.pos.x = -1;
			poseEstimate.pos.y = -1;
			poseEstimate.pos.ang = 0;
			poseEstimate.score = INFINITY;
			Eigen::Matrix<double, 9, 1> kalman_x;
			Eigen::Matrix<double, 9, 9> kalman_P;
			kalman_x << -1, -1, 0, 0, 0, 0, 0, 0, 0;
			kalman_P << 100, 0, 0, 0, 0, 0, 0, 0, 0,
						0, 100, 0, 0, 0, 0, 0, 0, 0,
						0, 0, 100, 0, 0, 0, 0, 0, 0,
						0, 0, 0, 1, 0, 0, 0, 0, 0,
						0, 0, 0, 0, 1, 0, 0, 0, 0,
						0, 0, 0, 0, 0, 1, 0, 0, 0,
						0, 0, 0, 0, 0, 0, 0.1, 0, 0,
						0, 0, 0, 0, 0, 0, 0, 0.1, 0,
						0, 0, 0, 0, 0, 0, 0, 0, 0.1;
			FAOutput.kalman_x = kalman_x;
			FAOutput.kalman_P = kalman_P;
			return FAOutput;
		}

		//��ƥ������Ȩ���ֵ
		double sumX = 0, sumY = 0, sumAngle = 0, sumScore = 0;
		int cnt;
		for (cnt = 0; cnt < lenPoseSimilar; cnt++) {
			double thisScore = 1 / pow(poseSimilar[cnt].score, 2);
			sumX += poseSimilar[cnt].pos.x * thisScore;
			sumY += poseSimilar[cnt].pos.y * thisScore;
			sumAngle += poseSimilar[cnt].pos.ang * thisScore;
			sumScore += thisScore;
		}
		poseEstimate.pos.x = sumX / sumScore;
		poseEstimate.pos.y = sumY / sumScore;
		poseEstimate.pos.ang = sumAngle / sumScore;
		poseEstimate.score = 1 / sqrt(sumScore / lenPoseSimilar);

		//printf("Score:%f\n", poseEstimate.score);

		//FAOutput = ukf(FAInput, poseEstimate);

		//poseEstimate.pos.x = FAOutput.kalman_x(0);
		//poseEstimate.pos.y = FAOutput.kalman_x(1);
		//poseEstimate.pos.ang = FAOutput.kalman_x(2);
		//FAOutput.poseEstimate = poseEstimate;

		free(poseAll);
		return FAOutput;
	}

	void thread_ScanToMapMatch(void *arg) {
		//���룺��ƥ��������߶ε����
		//���������ƥ�����ļ����״�λ�ú͵÷�
		structThreadSTMM *argSTMM = (structThreadSTMM*) arg;

		int lenScore = 0;
		int i = 0;
		//����ƥ�䷽ʽ
		for (i = 1; i <= 4; i++) {
			structStaEnd mapStaEndPoint, scanStaEndPoint;
			if (i == 1) {
				mapStaEndPoint.staX = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].x1;
				mapStaEndPoint.staY = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].y1;
				mapStaEndPoint.endX = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].x2;
				mapStaEndPoint.endY = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].y2;
				scanStaEndPoint.staX = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].x1;
				scanStaEndPoint.staY = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].y1;
				scanStaEndPoint.endX = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].x2;
				scanStaEndPoint.endY = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].y2;
			}
			else if (i == 2) {
				mapStaEndPoint.staX = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].x1;
				mapStaEndPoint.staY = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].y1;
				mapStaEndPoint.endX = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].x2;
				mapStaEndPoint.endY = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].y2;
				scanStaEndPoint.staX = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].x2;
				scanStaEndPoint.staY = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].y2;
				scanStaEndPoint.endX = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].x1;
				scanStaEndPoint.endY = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].y1;
			}
			else if (i == 3) {
				mapStaEndPoint.staX = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].x2;
				mapStaEndPoint.staY = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].y2;
				mapStaEndPoint.endX = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].x1;
				mapStaEndPoint.endY = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].y1;
				scanStaEndPoint.staX = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].x1;
				scanStaEndPoint.staY = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].y1;
				scanStaEndPoint.endX = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].x2;
				scanStaEndPoint.endY = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].y2;
			}
			else {
				mapStaEndPoint.staX = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].x2;
				mapStaEndPoint.staY = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].y2;
				mapStaEndPoint.endX = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].x1;
				mapStaEndPoint.endY = argSTMM->FAInput->mapLinesInfo[argSTMM->cntMapLine].y1;
				scanStaEndPoint.staX = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].x2;
				scanStaEndPoint.staY = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].y2;
				scanStaEndPoint.endX = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].x1;
				scanStaEndPoint.endY = argSTMM->FAInput->scanLinesInfo[argSTMM->cntScanLine].y1;
			}

			//����ƥ���׼��ͻ�׼�߶νǶ�
			structPosition mapPose, scanPose;
			mapPose.x = mapStaEndPoint.staX;
			mapPose.y = mapStaEndPoint.staY;
			mapPose.ang = NormalizedLineDirection(mapStaEndPoint);
			scanPose.x = scanStaEndPoint.staX;
			scanPose.y = scanStaEndPoint.staY;
			scanPose.ang = NormalizedLineDirection(scanStaEndPoint);

			structRotateScanIm RSI = rotateScanIm(argSTMM->FAInput, mapPose, scanPose);

			structScore tempScore;
			tempScore.pos = RSI.rotateLidarPos;
			tempScore.score = CalcScore(argSTMM->FAInput, RSI);
			free(RSI.rotateScanImPoint);

			//д����
			pthread_mutex_lock(&mutex);
			argSTMM->Score->push_back(tempScore);
			pthread_mutex_unlock(&mutex);
		}
		//��������������ͷŲ���
		pthread_mutex_lock(&mutex);
		num_done++;
		pthread_mutex_unlock(&mutex);
		free(argSTMM);
	}

	void ScanToMapMatch(structFAInput *FAInput, int cntMapLine, int cntScanLine, vector<structScore> *Score) {
		//���߳�����ƥ�䣨�����ã�
		int lenScore = 0;
		int i = 0;
		for (i = 1; i <= 4; i++) {
			structStaEnd mapStaEndPoint, scanStaEndPoint;
			if (i == 1) {
				mapStaEndPoint.staX = FAInput->mapLinesInfo[cntMapLine].x1;
				mapStaEndPoint.staY = FAInput->mapLinesInfo[cntMapLine].y1;
				mapStaEndPoint.endX = FAInput->mapLinesInfo[cntMapLine].x2;
				mapStaEndPoint.endY = FAInput->mapLinesInfo[cntMapLine].y2;
				scanStaEndPoint.staX = FAInput->scanLinesInfo[cntScanLine].x1;
				scanStaEndPoint.staY = FAInput->scanLinesInfo[cntScanLine].y1;
				scanStaEndPoint.endX = FAInput->scanLinesInfo[cntScanLine].x2;
				scanStaEndPoint.endY = FAInput->scanLinesInfo[cntScanLine].y2;
			}
			else if (i == 2) {
				mapStaEndPoint.staX = FAInput->mapLinesInfo[cntMapLine].x1;
				mapStaEndPoint.staY = FAInput->mapLinesInfo[cntMapLine].y1;
				mapStaEndPoint.endX = FAInput->mapLinesInfo[cntMapLine].x2;
				mapStaEndPoint.endY = FAInput->mapLinesInfo[cntMapLine].y2;
				scanStaEndPoint.staX = FAInput->scanLinesInfo[cntScanLine].x2;
				scanStaEndPoint.staY = FAInput->scanLinesInfo[cntScanLine].y2;
				scanStaEndPoint.endX = FAInput->scanLinesInfo[cntScanLine].x1;
				scanStaEndPoint.endY = FAInput->scanLinesInfo[cntScanLine].y1;
			}
			else if (i == 3) {
				mapStaEndPoint.staX = FAInput->mapLinesInfo[cntMapLine].x2;
				mapStaEndPoint.staY = FAInput->mapLinesInfo[cntMapLine].y2;
				mapStaEndPoint.endX = FAInput->mapLinesInfo[cntMapLine].x1;
				mapStaEndPoint.endY = FAInput->mapLinesInfo[cntMapLine].y1;
				scanStaEndPoint.staX = FAInput->scanLinesInfo[cntScanLine].x1;
				scanStaEndPoint.staY = FAInput->scanLinesInfo[cntScanLine].y1;
				scanStaEndPoint.endX = FAInput->scanLinesInfo[cntScanLine].x2;
				scanStaEndPoint.endY = FAInput->scanLinesInfo[cntScanLine].y2;
			}
			else {
				mapStaEndPoint.staX = FAInput->mapLinesInfo[cntMapLine].x2;
				mapStaEndPoint.staY = FAInput->mapLinesInfo[cntMapLine].y2;
				mapStaEndPoint.endX = FAInput->mapLinesInfo[cntMapLine].x1;
				mapStaEndPoint.endY = FAInput->mapLinesInfo[cntMapLine].y1;
				scanStaEndPoint.staX = FAInput->scanLinesInfo[cntScanLine].x2;
				scanStaEndPoint.staY = FAInput->scanLinesInfo[cntScanLine].y2;
				scanStaEndPoint.endX = FAInput->scanLinesInfo[cntScanLine].x1;
				scanStaEndPoint.endY = FAInput->scanLinesInfo[cntScanLine].y1;
			}

			structPosition mapPose, scanPose;
			mapPose.x = mapStaEndPoint.staX;
			mapPose.y = mapStaEndPoint.staY;
			mapPose.ang = NormalizedLineDirection(mapStaEndPoint);
			scanPose.x = scanStaEndPoint.staX;
			scanPose.y = scanStaEndPoint.staY;
			scanPose.ang = NormalizedLineDirection(scanStaEndPoint);

			structRotateScanIm RSI = rotateScanIm(FAInput, mapPose, scanPose);
			
			structScore tempScore;
			tempScore.pos = RSI.rotateLidarPos;
			tempScore.score = CalcScore(FAInput, RSI);
			free(RSI.rotateScanImPoint);
			Score->push_back(tempScore);
		}
	}

	double NormalizedLineDirection(structStaEnd lineStaEnd) {
		//����б�ʣ� ��һ���߶η���, �㣨x1, y1�� Ϊ��ʼ��
		//angleΪ�߶νǶ�, ��λΪy�ȣ���СΪ[-180��180]
		double angle;
		if (lineStaEnd.staX == lineStaEnd.endX && lineStaEnd.staY != lineStaEnd.endY) {
			if (lineStaEnd.staY < lineStaEnd.endY)
				angle = 90;
			else
				angle = -90;
		}
		else if (lineStaEnd.staX != lineStaEnd.endX && lineStaEnd.staY == lineStaEnd.endY) {
			if (lineStaEnd.staX < lineStaEnd.endX)
				angle = 0;
			else
				angle = 180;
		}
		else
			angle = (lineStaEnd.endY - lineStaEnd.staY) / (lineStaEnd.endX - lineStaEnd.staX);

		if (angle < 0 && lineStaEnd.staX > lineStaEnd.endX)
			angle += 180;

		if (angle > 0 && lineStaEnd.staX > lineStaEnd.endX)
			angle -= 180;

		return angle;
	}

	structRotateScanIm rotateScanIm(structFAInput *FAInput, structPosition mapPose, structPosition scanPose) {
		//��תRDP�����Լ���Score
		//LSD�߶κ�RDP�߶εĽǶȲ�
		double angDiff = mapPose.ang - scanPose.ang;

		int numScanImPoint = (int)FAInput->scanImPoint.size();
		int cnt;
		//������ԭ��ƽ�Ƶ���ƥ���RDP�߶εĻ�׼��
		structPosition *oriScanImPoint = (structPosition*)malloc(numScanImPoint * sizeof(structPosition));
		for (cnt = 0; cnt < numScanImPoint; cnt++) {
			oriScanImPoint[cnt].x = FAInput->scanImPoint[cnt].x - scanPose.x;
			oriScanImPoint[cnt].y = FAInput->scanImPoint[cnt].y - scanPose.y;
		}
		//���ǶȲ���תͼ���ԭ��ƽ�Ƶ�LSD�߶λ�׼��
		structPosition *rotateScanImPoint = (structPosition*)malloc(numScanImPoint * sizeof(structPosition));
		for (cnt = 0; cnt < numScanImPoint; cnt++) {
			rotateScanImPoint[cnt].x = oriScanImPoint[cnt].x * cosd(angDiff) - oriScanImPoint[cnt].y * sind(angDiff) + mapPose.x;
			rotateScanImPoint[cnt].y = oriScanImPoint[cnt].x * sind(angDiff) + oriScanImPoint[cnt].y * cosd(angDiff) + mapPose.y;
		}
		//�������״�������������ͬ�任
		structPosition rotateLidarPos;
		rotateLidarPos.x = (FAInput->lidarPos[0] - scanPose.x) * cosd(angDiff) - (FAInput->lidarPos[1] - scanPose.y) * sind(angDiff) + mapPose.x;
		rotateLidarPos.y = (FAInput->lidarPos[0] - scanPose.x) * sind(angDiff) + (FAInput->lidarPos[1] - scanPose.y) * cosd(angDiff) + mapPose.y;
		rotateLidarPos.ang = scanPose.ang + angDiff;

		//���ǶȲ������[-180,180]
		while (angDiff <= -180)
			angDiff += 360;
		while (angDiff > 180)
			angDiff -= 360;

		structRotateScanIm RSI;
		RSI.rotateScanImPoint = rotateScanImPoint;
		RSI.numScanImPoint = numScanImPoint;
		RSI.angDiff = angDiff;
		RSI.rotateLidarPos = rotateLidarPos;

		free(oriScanImPoint);
		return RSI;
	}

	double CalcScore(structFAInput *FAInput, structRotateScanIm RSI) {
		//���룺��ת���RDP���ƺ;���ͼmapCache
		//�������������Score��ԽСԽ��
		//sumDistΪ����ͣ�ValidΪ��mapCache��С�ڲ���z_occ_max_dis������
		double sumValidDist = 0, sumMaxDist = 0, numValidDistPoint = 0, numMaxDistPoint = 0;
		//AllΪ�������أ�ValidΪ�ڵ�ͼ�ڵ�����
		double numAllPoint = 0, numValidPoint = 0;

		int cnt;
		for (cnt = 0; cnt < RSI.numScanImPoint; cnt++) {
			int y = (int)round(RSI.rotateScanImPoint[cnt].y);
			int x = (int)round(RSI.rotateScanImPoint[cnt].x);
			//printf("%d %d %d %d\n", FAInput->mapIm.size[0], FAInput->mapIm.size[1], y, x);
			//printf("%f %f\n", RSI.rotateScanImPoint[cnt].y, RSI.rotateScanImPoint[cnt].x);
			if (y >= 0 && y < FAInput->mapCache.size[0] && x >= 0 && x < FAInput->mapCache.size[1]) {
				numValidPoint += 1;
				if (FAInput->mapCache.ptr<double>(y)[x] >= z_occ_max_dis)
					numMaxDistPoint += 1;
				else {
					sumValidDist += FAInput->mapCache.ptr<double>(y)[x];
					numValidDistPoint += 1;
				}
			}
		}
		numAllPoint = RSI.numScanImPoint;
		//���Ȩ�أ��ͷ�Max����
		sumMaxDist = 7 * numMaxDistPoint;
		double Score;
		if (numValidPoint == 0)
			Score = INFINITY;
		else
			Score = (sumValidDist + sumMaxDist) / (numValidPoint) + 10 * (numAllPoint - numValidPoint) / numValidPoint;
		//double Score = (sumValidDist + sumMaxDist) / numValidPoint;
		
		return Score;
	}

	int CompScore(const void *p1, const void *p2)
	{
		//��С��������
		return(*(structScore*)p2).score < (*(structScore*)p1).score ? 1 : -1;
	}

	structFAOutput ukf(structFAInput *FAInput, structScore poseEstimate) {
		Eigen::Matrix<double, 9, 9> kalman_Q;
		Eigen::Matrix<double, 3, 3> kalman_R;
		kalman_Q << 1, 0, 0, 0, 0, 0, 0, 0, 0,
					0, 1, 0, 0, 0, 0, 0, 0, 0,
					0, 0, 1, 0, 0, 0, 0, 0, 0,
					0, 0, 0, 0.01, 0, 0, 0, 0, 0,
					0, 0, 0, 0, 0.01, 0, 0, 0, 0,
					0, 0, 0, 0, 0, 0.01, 0, 0, 0,
					0, 0, 0, 0, 0, 0, 0.0001, 0, 0,
					0, 0, 0, 0, 0, 0, 0, 0.0001, 0,
					0, 0, 0, 0, 0, 0, 0, 0, 0.0001;// ��������Э�������
		kalman_R << 1, 0, 0,
					0, 1, 0,
					0, 0, 1;// ��������Э�������
		double kalman_t = 1; //���õ���
		
		Eigen::Matrix<double, 9, 1> kalman_x;
		Eigen::Matrix<double, 9, 9> kalman_P;
		kalman_x = FAInput->kalman_x;
		kalman_P = FAInput->kalman_P;
		kalman_x(0) += FAInput->ScanPose.x;
		kalman_x(1) += FAInput->ScanPose.y;
		kalman_x(2) += FAInput->ScanPose.ang;

		int L = 9; //kalman_x��ά��
		int m = 3; //poseEstimate.pos��ά��
		double alpha = 1e-2; //Ĭ��ϵ��
		double ki = 0; //Ĭ��ϵ��
		double beta = 2; //Ĭ��ϵ��
		double lambda = alpha * alpha * (L + ki) - L;
		double c = L + lambda;
		Eigen::Matrix<double, 1, 19> Wm;
		Eigen::Matrix<double, 1, 19> Wc;
		Wm(0) = lambda / c;
		Wc(0) = lambda / c;
		int cnt;
		for (cnt = 1; cnt < 2 * L + 1; cnt++) {
			Wm(cnt) = 0.5 / c;
			Wc(cnt) = 0.5 / c;
		}
		Wc(0) += 1 - alpha * alpha + beta;
		c = sqrt(c);

		// ��һ������ȡһ��sigma�㼯
		// sigma�㼯����״̬X�����ĵ㼯��X��6 * 13����ÿ��Ϊ1����
		Eigen::Matrix<double, 9, 9> A;
		Eigen::Matrix<double, 9, 9> Y;
		Eigen::Matrix<double, 9, 19> Xset;
		Eigen::LLT<Eigen::MatrixXd> lltOfA(kalman_P);
		A = lltOfA.matrixL();
		A = c * A.transpose();
		Y << kalman_x, kalman_x, kalman_x, kalman_x, kalman_x,\
			kalman_x, kalman_x, kalman_x, kalman_x;
		Xset << kalman_x, Y + A, Y - A;
		// �ڶ����������Ĳ�����sigma�㼯����һ��Ԥ�⣬�õ���ֵXImeans�ͷ���P1����sigma�㼯X1
		// ��״̬UT�任
		int LL = 2 * L + 1; //19
		Eigen::Matrix<double, 9, 1> Xmeans;
		Eigen::Matrix<double, 9, 19> Xsigma_pre;
		Eigen::Matrix<double, 9, 19> Xdiv;
		for (cnt = 0; cnt < LL; cnt++) {
			Xsigma_pre(0, cnt) = Xset(0, cnt) + kalman_t * Xset(3, cnt) + 0.5 * kalman_t * kalman_t * Xset(6, cnt);
			Xsigma_pre(1, cnt) = Xset(1, cnt) + kalman_t * Xset(4, cnt) + 0.5 * kalman_t * kalman_t * Xset(7, cnt);
			Xsigma_pre(2, cnt) = Xset(2, cnt) + kalman_t * Xset(5, cnt) + 0.5 * kalman_t * kalman_t * Xset(8, cnt);
			Xsigma_pre(3, cnt) = Xset(3, cnt) + kalman_t * Xset(6, cnt);
			Xsigma_pre(4, cnt) = Xset(4, cnt) + kalman_t * Xset(7, cnt);
			Xsigma_pre(5, cnt) = Xset(5, cnt) + kalman_t * Xset(8, cnt);
			Xsigma_pre(6, cnt) = Xset(6, cnt);
			Xsigma_pre(7, cnt) = Xset(7, cnt);
			Xsigma_pre(8, cnt) = Xset(8, cnt);

			Xmeans(0) += Wm(cnt) * Xsigma_pre(0, cnt);
			Xmeans(1) += Wm(cnt) * Xsigma_pre(1, cnt);
			Xmeans(2) += Wm(cnt) * Xsigma_pre(2, cnt);
			Xmeans(3) += Wm(cnt) * Xsigma_pre(3, cnt);
			Xmeans(4) += Wm(cnt) * Xsigma_pre(4, cnt);
			Xmeans(5) += Wm(cnt) * Xsigma_pre(5, cnt);
			Xmeans(6) += Wm(cnt) * Xsigma_pre(6, cnt);
			Xmeans(7) += Wm(cnt) * Xsigma_pre(7, cnt);
			Xmeans(8) += Wm(cnt) * Xsigma_pre(8, cnt);
		}
		int cnt2;
		for (cnt = 0; cnt < LL; cnt++) {
			for (cnt2 = 0; cnt2 < L; cnt2++) {
				Xdiv(cnt2, cnt) = Xsigma_pre(cnt2, cnt) - Xmeans(cnt2);
			}
		}
		Eigen::Matrix<double, 9, 9> P1;
		P1 = Xdiv * Wc.asDiagonal() * Xdiv.transpose() + kalman_Q;

		// ���塢�������õ��۲�Ԥ�⣬Z1ΪX1���ϵ�Ԥ�⣬ZpreΪZ1�ľ�ֵ��
		// PzzΪЭ����
		Eigen::Matrix<double, 3, 1> Zmeans;
		Eigen::Matrix<double, 3, 19> Zsigma_pre;
		Eigen::Matrix<double, 3, 19> Zdiv;
		for (cnt = 0; cnt < LL; cnt++) {
			Zsigma_pre(0, cnt) = Xsigma_pre(0, cnt);
			Zsigma_pre(1, cnt) = Xsigma_pre(1, cnt);
			Zsigma_pre(2, cnt) = Xsigma_pre(2, cnt);

			Zmeans(0) += Wm(cnt) * Zsigma_pre(0, cnt);
			Zmeans(1) += Wm(cnt) * Zsigma_pre(1, cnt);
			Zmeans(2) += Wm(cnt) * Zsigma_pre(2, cnt);
		}
		cnt2;
		for (cnt = 0; cnt < LL; cnt++) {
			for (cnt2 = 0; cnt2 < 3; cnt2++) {
				Zdiv(cnt2, cnt) = Xsigma_pre(cnt2, cnt) - Xmeans(cnt2);
			}
		}
		Eigen::Matrix<double, 3, 3> Pzz;
		Pzz = Zdiv * Wc.asDiagonal() * Zdiv.transpose() + kalman_R;

		// ���߲������㿨��������
		Eigen::Matrix<double, 9, 3> Pxz;
		Eigen::Matrix<double, 9, 3> K;
		Pxz = Xdiv * Wc.asDiagonal() * Zdiv.transpose();
		K = Pxz * Pzz.inverse();
		Eigen::Matrix<double, 3, 1> Zdiff;
		Zdiff(0) = poseEstimate.pos.x - Zmeans(0);
		Zdiff(1) = poseEstimate.pos.y - Zmeans(1);
		Zdiff(2) = poseEstimate.pos.ang - Zmeans(2);
		kalman_x = Xmeans + K * Zdiff;
		kalman_P = P1 - K * Pxz.transpose();
		structFAOutput FAOutput;
		FAOutput.kalman_x = kalman_x;
		FAOutput.kalman_P = kalman_P;

		return FAOutput;
	}
}