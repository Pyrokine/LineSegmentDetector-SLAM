#include <time.h>
#include <stdio.h>
#include <opencv.hpp>
#include <fstream>
#include <myLSD.h>
#include <myRDP.h>
#include <myFA.h>
#include <baseFunc.h>

using namespace cv;
using namespace std;

myfa::structFAInput trans2FA(myrdp::structFeatureScan FS, mylsd::structLSD LSD, Mat mapCache, structPosition lastPose,\
	Eigen::Matrix<double, 9, 1> kalman_x, Eigen::Matrix<double, 9, 9> kalman_P, structPosition ScanPose);

int main() {
	clock_t time_start, time_end;
	time_start = clock();
	//·��
	//string path1 = "../line_data/data0/";
	string path1 = "../data_20190523/data/";
	string path2;
	const char *path;
	//��ȡmapParam ��ͼ��Ϣ
	path2 = path1 + "mapParam.txt";
	path = path2.data();
	FILE *fp = fopen(path, "r");
	structMapParam mapParam;
	fscanf(fp, "%d %d %lf %lf %lf", &mapParam.oriMapCol, &mapParam.oriMapRow, &mapParam.mapResol, &mapParam.mapOriX, &mapParam.mapOriY);
	fclose(fp);
	int oriMapCol = mapParam.oriMapCol, oriMapRow = mapParam.oriMapRow;
	
	//��ȡmapValue ��ͼ��������
	int cnt_row, cnt_col;
	path2 = path1 + "mapValue.txt";
	path = path2.data();
	fp = fopen(path, "r");
	Mat mapValue = Mat::zeros(oriMapRow, oriMapCol, CV_8UC1);
	int max = 0;
	for (cnt_row = 0; cnt_row < oriMapRow; cnt_row++)
		for (cnt_col = 0; cnt_col < oriMapCol; cnt_col++)
			fscanf(fp, "%d", &mapValue.ptr<uint8_t>(cnt_row)[cnt_col]);
	fclose(fp);
	//imshow("1", mapValue);
	//waitKey(1);

	//��ȡOdometry ��̼�����
	vector<structPosition> Odom;
	path2 = path1 + "Odom.txt";
	path = path2.data();
	fp = fopen(path, "r");
	while (!feof(fp)) {
		structPosition tempOdom;
		fscanf(fp, "%lf %lf %lf", &tempOdom.x, &tempOdom.y, &tempOdom.ang);
		Odom.push_back(tempOdom);
	}
	fclose(fp);
	Odom[0].x = 0;
	//for (cnt_row = 0; cnt_row < Odom.size(); cnt_row++) {
	//	printf("%d : %f %f %f\n", cnt_row, Odom[cnt_row].x, Odom[cnt_row].y, Odom[cnt_row].ang);
	//}

	//����mapCache����������ƥ����������
	Mat mapCache = mylsd::createMapCache(mapValue, mapParam.mapResol, z_occ_max_dis);

	//LineSegmentDetector ��ȡ��ͼ�߽�ֱ����Ϣ
	mylsd::structLSD LSD = mylsd::myLineSegmentDetector(mapValue, oriMapCol, oriMapRow, lsd_sca, lsd_sig, lsd_angThre, lsd_denThre, pseBin);
	Mat Display = mapValue.clone();

	//printf("%d %d\n", Display.size[0], Display.size[1]);
	//imshow("mapCache", mapCache);
	//imshow("Display", Display);
	//waitKey(0);

	//��ʼ���˶�����
	structPosition lastPose;
	lastPose.x = -1;
	lastPose.y = -1;
	lastPose.ang = 0;
	Eigen::Matrix<double, 9, 1> kalman_x;
	Eigen::Matrix<double, 9, 9> kalman_P;
	kalman_x << -1, -1, 0, 0, 0, 0, 0, 0, 0;
	kalman_P << 100, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 100, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 100, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 1, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 1, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 1, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0.1, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0.1, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0.1;

	//��ȡ�״���Ϣ
	path2 = path1 + "Lidar.txt";
	path = path2.data();
	fp = fopen(path, "r");
	int i = 0, len_lp = 0, cnt_frame = 1;
	myrdp::structLidarPointPolar lidarPointPolar[360];
	while (!feof(fp)) {
		len_lp = 0;
		bool is_EOF = false;
		printf("��%d֡:\n", cnt_frame++);
		//ÿ֡���360֡���� ѭ����ȡ�����룩
		for (i = 0; i < pointPerLoop; i++) {
			double val1, val2;
			if (feof(fp)) {
				is_EOF = true;
				break;
			}
			fscanf(fp, "%lf%lf", &val1, &val2);

			if (val1 != INFINITY) {
				lidarPointPolar[len_lp].range = val1;
				lidarPointPolar[len_lp].angle = val2;
				lidarPointPolar[len_lp].split = false;
				len_lp++;
			}
		}
		if (is_EOF == false) {
			//ƥ���״���������ͼ���� ���������������ʵ����
			myrdp::structFeatureScan FS = FeatureScan(mapParam, lidarPointPolar, len_lp, rdp_leastPoint, rdp_threLine, rdp_leastDist);
			
			double estimatePose_realworld[3];
			double estimatePose[3];
			Mat poseAll;

			structPosition ScanPose;
			ScanPose.x = Odom[cnt_frame].x - Odom[cnt_frame - 1].x;
			ScanPose.y = Odom[cnt_frame].y - Odom[cnt_frame - 1].y;
			ScanPose.ang = Odom[cnt_frame].ang - Odom[cnt_frame - 1].ang;

			myfa::structFAInput FAInput = trans2FA(FS, LSD, mapCache, lastPose, kalman_x, kalman_P, ScanPose);
			myfa::structFAOutput FA = myfa::FeatureAssociation(&FAInput);

			kalman_x = FA.kalman_x;
			kalman_P = FA.kalman_P;
			lastPose.x = FA.kalman_x(0);
			lastPose.y = FA.kalman_x(1);
			lastPose.ang = FA.kalman_x(2);
			printf("x:%f y:%f ang:%f\n\n", kalman_x(0), kalman_x(1), kalman_x(2));

			//��ͼ����������ͼ��
			circle(Display, Point((int)kalman_x(0), (int)kalman_x(1)), 1, Scalar(255, 255, 255));
			imshow("Display", Display);
			waitKey(1);
		}
		else
			destroyWindow("Display");

		if (cnt_frame > Odom.size())
			break;
	}
	fclose(fp);

	imshow("MapGray", mapValue);
	time_end = clock();
	printf("time = %lf\n", (double)(time_end - time_start) / CLOCKS_PER_SEC);
	imshow("lineIm", Display);
	waitKey(0);
	destroyAllWindows();
	return 0;
}

myfa::structFAInput trans2FA(myrdp::structFeatureScan FS, mylsd::structLSD LSD, Mat mapCache, structPosition lastPose,\
	Eigen::Matrix<double, 9, 1> kalman_x, Eigen::Matrix<double, 9, 9> kalman_P, structPosition ScanPose) {
	//�����ݸ�ʽתΪFeatureAssociation��ʽ
	myfa::structFAInput FA;
	int i;
	//scanLinesInfo
	FA.scanLinesInfo.resize(FS.len_linesInfo);
	for (i = 0; i < FS.len_linesInfo; i++) {
		FA.scanLinesInfo[i].k = FS.linesInfo[i].k;
		FA.scanLinesInfo[i].b = FS.linesInfo[i].b;
		FA.scanLinesInfo[i].dx = FS.linesInfo[i].dx;
		FA.scanLinesInfo[i].dy = FS.linesInfo[i].dy;
		FA.scanLinesInfo[i].x1 = FS.linesInfo[i].x1;
		FA.scanLinesInfo[i].y1 = FS.linesInfo[i].y1;
		FA.scanLinesInfo[i].x2 = FS.linesInfo[i].x2;
		FA.scanLinesInfo[i].y2 = FS.linesInfo[i].y2;
		FA.scanLinesInfo[i].len = FS.linesInfo[i].len;
	}
	//mapLinesInfo
	FA.mapLinesInfo.resize(LSD.len_linesInfo);
	for (i = 0; i < LSD.len_linesInfo; i++) {
		FA.mapLinesInfo[i].k = LSD.linesInfo[i].k;
		FA.mapLinesInfo[i].b = LSD.linesInfo[i].b;
		FA.mapLinesInfo[i].dx = LSD.linesInfo[i].dx;
		FA.mapLinesInfo[i].dy = LSD.linesInfo[i].dy;
		FA.mapLinesInfo[i].x1 = LSD.linesInfo[i].x1;
		FA.mapLinesInfo[i].y1 = LSD.linesInfo[i].y1;
		FA.mapLinesInfo[i].x2 = LSD.linesInfo[i].x2;
		FA.mapLinesInfo[i].y2 = LSD.linesInfo[i].y2;
		FA.mapLinesInfo[i].len = LSD.linesInfo[i].len;
	}
	//lidarPos
	FA.lidarPos[0] = (int)round(FS.lidarPos.x);
	FA.lidarPos[1] = (int)round(FS.lidarPos.y);
	//printf("x:%lf y:%lf\n", FS.lidarPos.x, FS.lidarPos.y);
	FA.scanImPoint = FS.scanImPoint;
	FA.mapCache = mapCache;
	FA.lastPose = lastPose;
	FA.kalman_x = kalman_x;
	FA.kalman_P = kalman_P;
	FA.ScanPose = ScanPose;

	return FA;
}

